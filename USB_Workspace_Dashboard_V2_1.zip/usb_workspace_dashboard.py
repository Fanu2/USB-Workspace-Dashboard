
import sys, os, json, time, ctypes
from pathlib import Path
from dataclasses import dataclass, asdict
from collections import Counter
from PySide6.QtCore import Qt, QThread, Signal, QObject
from PySide6.QtGui import QFont, QDesktopServices
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QGridLayout, QLineEdit, QListWidget, QListWidgetItem,
    QMessageBox, QFileDialog, QProgressBar, QFrame, QScrollArea
)

APP_NAME = "USB Workspace Dashboard"
CACHE_DIR = ".usb_workspace"
CACHE_FILE = "index.json"

IGNORE_DIRS = {
    ".git", ".svn", ".hg", "__pycache__", "node_modules",
    "$Recycle.Bin", "System Volume Information", ".usb_workspace"
}

CATEGORIES = {
    "Documents": {".pdf",".doc",".docx",".odt",".rtf",".txt",".md",".rst",".csv"},
    "Applications": {".exe",".msi",".bat",".cmd",".appimage",".deb",".rpm"},
    "AI & Projects": {".py",".pyw",".ipynb",".js",".ts",".tsx",".jsx",".json",".toml"},
    "Books": {".epub",".mobi",".azw",".azw3",".fb2",".djvu"},
    "Python": {".py",".pyw",".ipynb",".whl"},
    "Linux": {".iso",".img",".appimage",".deb",".rpm",".sh",".run"},
    "Data": {".csv",".xlsx",".xls",".json",".xml",".sqlite",".sqlite3",".db",".parquet"},
    "Archives": {".zip",".7z",".rar",".tar",".gz",".bz2",".xz",".tgz",".tar.gz"},
}

CATEGORY_ICONS = {
    "Documents":"📄", "Applications":"🚀", "AI & Projects":"🧠",
    "Books":"📚", "Python":"🐍", "Linux":"🐧",
    "Data":"📊", "Archives":"🗜️"
}

def detect_usb_drives():
    drives = []
    if sys.platform == "win32":
        mask = ctypes.windll.kernel32.GetLogicalDrives()
        get_type = ctypes.windll.kernel32.GetDriveTypeW
        for i in range(26):
            if mask & (1 << i):
                drive = f"{chr(65+i)}:\\"
                if get_type(drive) == 2 and Path(drive).is_dir():
                    drives.append(Path(drive))
    else:
        candidates = [Path("/media"), Path("/run/media"), Path("/mnt")]
        seen = set()
        for base in candidates:
            if base.exists():
                for p in base.iterdir():
                    if p.is_dir() and str(p) not in seen:
                        drives.append(p)
                        seen.add(str(p))
    return drives

def classify_file(path):
    suffixes = [s.lower() for s in path.suffixes]
    name = path.name.lower()
    if name.endswith(".tar.gz"):
        ext = ".tar.gz"
    else:
        ext = path.suffix.lower()

    for cat, exts in CATEGORIES.items():
        if ext in exts:
            return cat
    return "Other"

def project_type(directory):
    try:
        names = {p.name.lower() for p in directory.iterdir() if p.is_file()}
    except OSError:
        return None
    if ".git" in {p.name.lower() for p in directory.iterdir()} if directory.exists() else False:
        return "Git Project"
    if "pyproject.toml" in names or "requirements.txt" in names or "setup.py" in names:
        return "Python Project"
    if "package.json" in names:
        return "Node Project"
    if "dockerfile" in names or "compose.yaml" in names or "docker-compose.yml" in names:
        return "Docker Project"
    return None

def safe_stat(path):
    try:
        st = path.stat()
        return st.st_size, st.st_mtime_ns
    except OSError:
        return 0, 0

class ScanWorker(QObject):
    progress = Signal(int, int, str)
    finished = Signal(dict, dict, float)
    error = Signal(str)
    cancelled = Signal()

    def __init__(self, root, old_index=None):
        super().__init__()
        self.root = Path(root)
        self.old_index = old_index or {}
        self._cancel = False

    def cancel(self):
        self._cancel = True

    def run(self):
        started = time.time()
        items = {}
        counts = Counter()
        scanned = 0

        try:
            stack = [self.root]
            while stack:
                if self._cancel:
                    self.cancelled.emit()
                    return
                directory = stack.pop()
                try:
                    with os.scandir(directory) as it:
                        for entry in it:
                            if self._cancel:
                                self.cancelled.emit()
                                return
                            try:
                                if entry.name in IGNORE_DIRS:
                                    continue
                                p = Path(entry.path)
                                rel = str(p.relative_to(self.root))
                                if entry.is_dir(follow_symlinks=False):
                                    stack.append(p)
                                    continue
                                if not entry.is_file(follow_symlinks=False):
                                    continue

                                st = entry.stat(follow_symlinks=False)
                                category = classify_file(p)
                                record = {
                                    "path": rel,
                                    "name": entry.name,
                                    "category": category,
                                    "size": st.st_size,
                                    "mtime_ns": st.st_mtime_ns,
                                    "is_dir": False,
                                }
                                items[rel] = record
                                counts[category] += 1
                                scanned += 1
                                if scanned % 250 == 0:
                                    self.progress.emit(scanned, len(items), rel)
                            except (OSError, ValueError):
                                continue
                except OSError:
                    continue

            # Add project directories as lightweight records.
            for rel, rec in list(items.items()):
                parent = (self.root / rel).parent
                if parent == self.root:
                    continue
                ptype = project_type(parent)
                if ptype:
                    p_rel = str(parent.relative_to(self.root))
                    key = "__project__/" + p_rel
                    items[key] = {
                        "path": p_rel,
                        "name": parent.name,
                        "category": "AI & Projects",
                        "size": 0,
                        "mtime_ns": 0,
                        "is_dir": True,
                        "project_type": ptype,
                    }

            elapsed = time.time() - started
            self.finished.emit(items, dict(counts), elapsed)
        except Exception as e:
            self.error.emit(str(e))

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.root = None
        self.items = {}
        self.counts = {}
        self.worker = None
        self.thread = None
        self.setWindowTitle(APP_NAME)
        self.resize(1180, 800)
        self.build_ui()
        self.refresh_usb()

    def build_ui(self):
        outer = QWidget()
        self.setCentralWidget(outer)
        main = QVBoxLayout(outer)
        main.setContentsMargins(28,24,28,24)
        main.setSpacing(16)

        top = QHBoxLayout()
        title = QLabel("USB Workspace")
        title.setObjectName("title")
        top.addWidget(title)
        top.addStretch()

        self.status = QLabel("Starting…")
        self.status.setObjectName("status")
        top.addWidget(self.status)
        main.addLayout(top)

        sub = QHBoxLayout()
        self.location = QLabel("No workspace selected")
        self.location.setObjectName("location")
        sub.addWidget(self.location)
        sub.addStretch()
        self.choose_btn = QPushButton("Choose USB / Folder")
        self.choose_btn.clicked.connect(self.choose_folder)
        sub.addWidget(self.choose_btn)
        self.refresh_btn = QPushButton("Refresh")
        self.refresh_btn.clicked.connect(self.refresh_usb)
        sub.addWidget(self.refresh_btn)
        self.cancel_btn = QPushButton("Cancel Scan")
        self.cancel_btn.clicked.connect(self.cancel_scan)
        self.cancel_btn.setEnabled(False)
        sub.addWidget(self.cancel_btn)
        main.addLayout(sub)

        self.progress = QProgressBar()
        self.progress.setRange(0,0)
        self.progress.setVisible(False)
        main.addWidget(self.progress)

        self.stats = QLabel("Loading index…")
        self.stats.setObjectName("stats")
        main.addWidget(self.stats)

        search_row = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search indexed files and folders…")
        self.search.textChanged.connect(self.do_search)
        search_row.addWidget(self.search)
        main.addLayout(search_row)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        content = QWidget()
        self.grid = QGridLayout(content)
        self.grid.setContentsMargins(4,4,4,4)
        self.grid.setSpacing(14)
        scroll.setWidget(content)
        main.addWidget(scroll, 1)

        self.results = QListWidget()
        self.results.setVisible(False)
        self.results.itemDoubleClicked.connect(self.open_result)
        main.addWidget(self.results, 1)

        self.setStyleSheet("""
        QMainWindow, QWidget { background:#10141b; color:#e8edf4; }
        #title { font-size:30px; font-weight:700; }
        #status { padding:7px 12px; border-radius:12px; background:#193b2a; color:#8ef0b0; font-weight:700; }
        #location, #stats { color:#aeb8c7; }
        QLineEdit { background:#171d27; border:1px solid #2a3444; border-radius:10px; padding:12px; color:#fff; }
        QPushButton { background:#1d2633; border:1px solid #344154; border-radius:9px; padding:9px 14px; }
        QPushButton:hover { background:#273345; }
        QFrame.card { background:#171d27; border:1px solid #293548; border-radius:16px; }
        QLabel.cardTitle { font-size:18px; font-weight:700; }
        QLabel.cardMeta { color:#9eabba; }
        QListWidget { background:#171d27; border:1px solid #293548; border-radius:12px; padding:6px; }
        QProgressBar { height:10px; border:none; background:#202735; border-radius:5px; }
        QProgressBar::chunk { background:#58a6ff; border-radius:5px; }
        """)

    def refresh_usb(self):
        drives = detect_usb_drives()
        if drives:
            self.set_root(drives[0])
        elif self.root is None or not Path(self.root).exists():
            self.set_root(Path(__file__).resolve().parent)
        else:
            self.load_cache_then_scan()

    def set_root(self, root):
        self.root = Path(root)
        self.location.setText(f"Workspace: {self.root}")
        self.load_cache_then_scan()

    def cache_path(self):
        return self.root / CACHE_DIR / CACHE_FILE

    def load_cache_then_scan(self):
        self.load_cache()
        self.render_cards()
        self.start_scan()

    def load_cache(self):
        try:
            p = self.cache_path()
            if p.exists():
                data = json.loads(p.read_text(encoding="utf-8"))
                self.items = data.get("items", {})
                self.counts = data.get("counts", {})
                self.status.setText("INDEX READY")
                self.stats.setText(f"Cached index: {len(self.items):,} items")
            else:
                self.items, self.counts = {}, {}
                self.status.setText("BUILDING INDEX")
                self.stats.setText("No cached index yet — first scan will build one.")
        except Exception:
            self.items, self.counts = {}, {}
            self.status.setText("BUILDING INDEX")

    def save_cache(self, items, counts, elapsed):
        try:
            cache = self.root / CACHE_DIR
            cache.mkdir(exist_ok=True)
            payload = {
                "version": 1,
                "root": str(self.root),
                "generated": time.time(),
                "scan_seconds": round(elapsed, 2),
                "items": items,
                "counts": counts,
            }
            tmp = cache / "index.tmp"
            tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
            tmp.replace(self.cache_path())
        except Exception:
            pass

    def start_scan(self):
        if self.thread and self.thread.isRunning():
            return
        self.progress.setVisible(True)
        self.cancel_btn.setEnabled(True)
        self.refresh_btn.setEnabled(False)
        self.status.setText("SCANNING")
        self.thread = QThread()
        self.worker = ScanWorker(self.root, self.items)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.progress.connect(self.scan_progress)
        self.worker.finished.connect(self.scan_finished)
        self.worker.error.connect(self.scan_error)
        self.worker.cancelled.connect(self.scan_cancelled)
        self.worker.finished.connect(self.thread.quit)
        self.worker.error.connect(self.thread.quit)
        self.worker.cancelled.connect(self.thread.quit)
        self.thread.finished.connect(self.thread_cleanup)
        self.thread.start()

    def scan_progress(self, scanned, found, current):
        self.progress.setRange(0,0)
        self.stats.setText(f"Scanning… {scanned:,} files | {found:,} indexed | {current}")

    def scan_finished(self, items, counts, elapsed):
        self.items, self.counts = items, counts
        self.save_cache(items, counts, elapsed)
        self.render_cards()
        self.status.setText("INDEX READY")
        self.stats.setText(f"{len(items):,} items indexed in {elapsed:.1f}s")
        self.progress.setVisible(False)
        self.cancel_btn.setEnabled(False)
        self.refresh_btn.setEnabled(True)

    def scan_error(self, message):
        self.status.setText("SCAN ERROR")
        self.stats.setText(message)
        self.progress.setVisible(False)
        self.cancel_btn.setEnabled(False)
        self.refresh_btn.setEnabled(True)

    def scan_cancelled(self):
        self.status.setText("SCAN CANCELLED")
        self.progress.setVisible(False)
        self.cancel_btn.setEnabled(False)
        self.refresh_btn.setEnabled(True)

    def thread_cleanup(self):
        self.worker = None
        self.thread = None

    def cancel_scan(self):
        if self.worker:
            self.worker.cancel()

    def clear_grid(self):
        while self.grid.count():
            item = self.grid.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()

    def render_cards(self):
        self.results.setVisible(False)
        self.clear_grid()
        cats = list(CATEGORIES.keys())
        cats.append("Other")
        for i, cat in enumerate(cats):
            count = self.counts.get(cat, 0)
            card = QFrame()
            card.setProperty("class","card")
            card.setStyleSheet("QFrame { background:#171d27; border:1px solid #293548; border-radius:16px; }")
            lay = QVBoxLayout(card)
            lay.setContentsMargins(18,16,18,16)
            icon = QLabel(CATEGORY_ICONS.get(cat,"📁"))
            icon.setStyleSheet("font-size:30px;")
            lay.addWidget(icon)
            t = QLabel(cat)
            t.setObjectName("cardTitle")
            t.setStyleSheet("font-size:18px; font-weight:700;")
            lay.addWidget(t)
            m = QLabel(f"{count:,} items")
            m.setObjectName("cardMeta")
            m.setStyleSheet("color:#9eabba;")
            lay.addWidget(m)
            b = QPushButton("Open")
            b.clicked.connect(lambda checked=False, c=cat: self.show_category(c))
            lay.addWidget(b)
            self.grid.addWidget(card, i//4, i%4)

    def show_category(self, category):
        self.results.clear()
        self.search.clear()
        matches = [r for r in self.items.values() if r.get("category") == category]
        matches.sort(key=lambda x: x.get("path","").lower())
        self.results.setVisible(True)
        for rec in matches[:1000]:
            label = f"{rec.get('name', Path(rec['path']).name)}  —  {rec['path']}"
            item = QListWidgetItem(label)
            item.setData(Qt.UserRole, rec)
            self.results.addItem(item)
        self.stats.setText(f"{len(matches):,} {category} items | showing up to 1,000")

    def do_search(self, text):
        text = text.strip().lower()
        if not text:
            self.results.setVisible(False)
            return
        self.results.clear()
        self.results.setVisible(True)
        matches = []
        for rec in self.items.values():
            hay = (rec.get("name","") + " " + rec.get("path","")).lower()
            if text in hay:
                matches.append(rec)
        matches.sort(key=lambda x: x.get("path","").lower())
        for rec in matches[:1000]:
            item = QListWidgetItem(f"{rec.get('name')}  —  {rec.get('path')}")
            item.setData(Qt.UserRole, rec)
            self.results.addItem(item)
        self.stats.setText(f"{len(matches):,} matches | showing up to 1,000")

    def open_result(self, item):
        rec = item.data(Qt.UserRole)
        p = self.root / rec["path"]
        if p.exists():
            self.open_path(p)

    def open_path(self, path):
        try:
            if sys.platform == "win32":
                os.startfile(str(path))
            elif sys.platform == "darwin":
                os.system(f'open "{path}"')
            else:
                QDesktopServices.openUrl(path.as_uri())
        except Exception as e:
            QMessageBox.warning(self, "Open failed", str(e))

    def choose_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Choose USB workspace")
        if folder:
            self.set_root(Path(folder))

def main():
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setFont(QFont("Segoe UI", 10))
    window = MainWindow()
    window.show()
    return app.exec()

if __name__ == "__main__":
    sys.exit(main())
