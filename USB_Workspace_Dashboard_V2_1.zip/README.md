# USB Workspace Dashboard V2.1

A fast, portable PySide6 dashboard for turning a USB drive into a clickable digital workspace.

## What changed in V2.1

V2.1 is focused on the 1 TB USB performance problem identified in V2.

### Faster and more responsive
- The scan runs in a background `QThread`, so the GUI remains responsive.
- The dashboard immediately loads a cached index when one exists.
- The index is stored on the workspace itself:
  `.usb_workspace/index.json`
- A progress/status area shows scanning activity.
- Scanning can be cancelled.
- The GUI does not repeatedly rescan the USB just to calculate category counts.
- `os.scandir()` is used for the filesystem walk instead of `Path.rglob()`.
- Common noise directories are skipped.
- Symlinks/junctions are not followed.

## First run vs later runs

### First run
The first scan still has to discover the USB contents. On a very large drive, the time depends mainly on the number of files/directories rather than the nominal 1 TB capacity.

### Later runs
The dashboard first loads the previous index, so the interface becomes usable immediately. A background refresh then rebuilds the index.

This V2.1 implementation is intentionally conservative: it uses a reliable full metadata walk in the background rather than pretending that an incremental scan is complete when it is not. A future SQLite/index-delta version can make very large collections substantially faster.

## Categories

- Documents
- Applications
- AI & Projects
- Books
- Python
- Linux
- Data
- Archives
- Other

## Run

```powershell
python usb_workspace_dashboard.py
```

PySide6 is required.

## Portable design

The dashboard is designed to live on the USB drive. The `.usb_workspace` directory contains the local index and can be ignored or deleted if you want to rebuild the index.

## Safety

The dashboard indexes filenames and filesystem metadata. It does not open document contents during scanning.

Double-clicking a result uses the operating system's normal file association.

## Suggested V2.2 / V3

1. True incremental directory-level indexing.
2. SQLite index for very large USB drives.
3. Quick Scan / Deep Scan modes.
4. Recently used items.
5. Favorites / pinned folders.
6. File-type filters.
7. Project cards with detected project type.
8. Optional thumbnails for selected document types.
