@echo off
python "%~dp0usb_workspace_dashboard.py"
